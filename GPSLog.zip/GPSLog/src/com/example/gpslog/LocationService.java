package com.example.gpslog;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class LocationService extends Service {
	public static final String TAG = "LocationService";
	// Acquire a reference to the system Location Manager
	LocationManager locationManager;
	Location oldLocation;
	long lastTime = System.currentTimeMillis();
	long startTime = System.currentTimeMillis();
	    
	// Define a listener that responds to location updates
	LocationListener locationListener = new LocationListener() {
		public void onLocationChanged(Location location) {
			// Called when a new location is found by the network location provider.
			changedLocation(location);
		}

		public void onStatusChanged(String provider, int status, Bundle extras) {
		}

		public void onProviderEnabled(String provider) {
		}

		public void onProviderDisabled(String provider) {
		}
	};
	
	protected void changedLocation (Location location) {
		if (oldLocation == null) oldLocation = location;
		long timedelta =  System.currentTimeMillis() - lastTime;
		double td = (double)timedelta / 1000.0;
		double latdelta = location.getLatitude() - oldLocation.getLatitude();
		double londelta = location.getLongitude() - oldLocation.getLongitude();
		double altdelta = location.getAltitude() - oldLocation.getAltitude();
//		Log.d(TAG, "Changed location");
		
		oldLocation = location;
		lastTime = System.currentTimeMillis();
			
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		Manager.buffer += timeStamp + ", " + location.getLatitude() + ", " + location.getLongitude() + "\r\n";

		Manager.outputStr = "You are here:\n" 
				+ "Lat: " + location.getLatitude()
				+ "\nLon: " + location.getLongitude() 
				+ "\nAlt: " + location.getAltitude() + "\nTime since last update: "
				+ (td) + " seconds\nLat Delta: " + latdelta
				+ "\nLon Delta: " + londelta + "\nAlt Delta: " + altdelta 
				+ "\nSpeed (MPH): " + (location.getSpeed() *  2.2369362920544)
				+ "\nRun time: " + ((System.currentTimeMillis()-startTime)/1000) + " seconds\n";
	}

	@Override
	public void onCreate() {
		super.onCreate();
		Log.d(TAG, "onCreate()");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
		// Register the listener with the Location Manager to receive location updates
//		locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 3, locationListener);
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
//		Toast.makeText(this, "service starting", Toast.LENGTH_SHORT).show();
		
		// If we get killed, after returning from here, restart
		return START_NOT_STICKY;
	}	
	
	@Override
	public void onDestroy() {
		Log.d(TAG, "onDestroy");
//		Toast.makeText(this, "service done", Toast.LENGTH_SHORT).show();
//		writeLog();
		super.onDestroy();
	}

	private static final int TWO_MINUTES = 1000 * 60 * 2;

	/**
	 * Determines whether one Location reading is better than the current
	 * Location fix
	 * 
	 * @param location
	 *            The new Location that you want to evaluate
	 * @param currentBestLocation
	 *            The current Location fix, to which you want to compare the new
	 *            one
	 */
	protected boolean isBetterLocation(Location location,
			Location currentBestLocation) {
		if (currentBestLocation == null) {
			// A new location is always better than no location
			return true;
		}

		// Check whether the new location fix is newer or older
		long timeDelta = location.getTime() - currentBestLocation.getTime();
		boolean isSignificantlyNewer = timeDelta > TWO_MINUTES;
		boolean isSignificantlyOlder = timeDelta < -TWO_MINUTES;
		boolean isNewer = timeDelta > 0;

		// If it's been more than two minutes since the current location, use
		// the new location
		// because the user has likely moved
		if (isSignificantlyNewer) {
			return true;
			// If the new location is more than two minutes older, it must be
			// worse
		} else if (isSignificantlyOlder) {
			return false;
		}

		// Check whether the new location fix is more or less accurate
		int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation
				.getAccuracy());
		boolean isLessAccurate = accuracyDelta > 0;
		boolean isMoreAccurate = accuracyDelta < 0;
		boolean isSignificantlyLessAccurate = accuracyDelta > 200;

		// Check if the old and new location are from the same provider
		boolean isFromSameProvider = isSameProvider(location.getProvider(),
				currentBestLocation.getProvider());

		// Determine location quality using a combination of timeliness and
		// accuracy
		if (isMoreAccurate) {
			return true;
		} else if (isNewer && !isLessAccurate) {
			return true;
		} else if (isNewer && !isSignificantlyLessAccurate
				&& isFromSameProvider) {
			return true;
		}
		return false;
	}

	/** Checks whether two providers are the same */
	private boolean isSameProvider(String provider1, String provider2) {
		if (provider1 == null) {
			return provider2 == null;
		}
		return provider1.equals(provider2);
	}

	@Override
	public IBinder onBind(Intent intent) {
		// We don't provide binding, so return null
		return null;
	}
}
