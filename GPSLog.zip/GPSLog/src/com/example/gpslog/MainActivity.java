package com.example.gpslog;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.example.gpslog.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

/**
 * GPS Logger
 * Logs GPS coordinates to a file along with the date/time you were there.
 * Used by Airodump CSV tools to provide GPS output.
 * @author Christopher Bolduc
 * @date 2015-02-05
 */

public class MainActivity extends Activity implements Runnable, View.OnClickListener {
	TextView tv;
	Button saveBtn;
	public static final String TAG = "MainActivity";
	String outputStr;
	boolean running = false;
	Intent intent;

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            tv.setText(outputStr);           
        }
    };
    
    public void output (String text) {
        outputStr = text + "\n";
        handler.sendMessage(handler.obtainMessage());
    }

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// if (savedInstanceState == null) {
		// getFragmentManager().beginTransaction()
		// .add(R.id.container, new PlaceholderFragment()).commit();
		// }

		tv = (TextView) findViewById(R.id.outputText);
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		saveBtn = (Button) findViewById(R.id.saveButton);
		saveBtn.setOnClickListener(this);
		
		intent = new Intent(this, LocationService.class);
		startService(intent);

		running = true;
		new Thread(this).start();
	}
	
	public void run() {
		while (running) {
			if (Manager.outputStr != null)
				output(Manager.outputStr);
			else
				output("Waiting for location");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
		
	@Override
	public void onPause() {
		Log.d(TAG, "onPause()");
		running = false;
		super.onPause();
	}
	
	@Override
	public void onResume() {
		Log.d(TAG, "onResume()");
		if (!running) {
			running = true;
			new Thread(this).start();
		}
		super.onResume();
	}
	
	@Override
	protected void onDestroy() {
		Log.d(TAG, "onDestroy");
		running = false;
		this.stopService(intent);
		super.onDestroy();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View arg0) {
		if (arg0 == saveBtn) {
			writeLog();
		}
	}
	
	public void writeLog() {
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		File mediaStorageDir;
		PrintWriter writer;
		String filepath = "";
		
		if (Environment.getExternalStorageState() == null) {
            //create new file directory object
			mediaStorageDir = new File(Environment.getDataDirectory() + "/GPSLog/");
		} else {
            // search for directory on SD card
            mediaStorageDir = new File(Environment.getExternalStorageDirectory() + "/GPSLog/");
		}
		// Create the storage directory if it does not exist
	    if (! mediaStorageDir.exists()){
	        if (! mediaStorageDir.mkdirs()){
	        	Log.d(TAG, "Error creating media storage directory");
	            return;
	        }
	    }
		try {
			filepath = mediaStorageDir.getPath() + File.separator + timeStamp + ".csv";
			writer = new PrintWriter(filepath, "UTF-8");
//			if (writer == null) {
//				Log.d(TAG, "Unspecified error writing log.");
//				return;
//			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			Toast.makeText(this, "Error opening " + filepath, Toast.LENGTH_SHORT).show();
			return;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
			return;
		}
		writer.write(Manager.buffer);
		writer.close();
		Toast.makeText(this, "Saved to " + filepath, Toast.LENGTH_SHORT).show();
	}	
}
