package com.example.gpslog;

public class Manager {
	public static String outputStr;
	public static String buffer = "";
}
